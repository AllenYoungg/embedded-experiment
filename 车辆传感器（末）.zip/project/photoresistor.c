#include "photoresistor.h"

void ledInit(void)
{
	softPwmCreate(LedPinRed,  0, 100);
}

void ledColorSet(uchar r_val)
{
	softPwmWrite(LedPinRed,   r_val);
}

