#include "ultrasonic.h"
#include "photoresistor.h"
#include "lcd.h"
#include "mpu.h"
#include "rotary_encoder.h"

void display_distance(char *distance, char *str, int count)//lcd��ʾ����
{
	int length = 0;
	int i=0;
	sprintf(str, "%d", count);
	length = strlen(str);
	for(i=length; i<5; i++)
	{
		str[i] = ' ';
	}
	str[i] = '\0';
	strcat(distance, str);
	write(0, 1, distance);//��һ�е�������ʾ����
	distance[9] = '\0';
	}

int main()
{
	char distance[16] = "distance:\0";
	char str[6] = "\0";
	float dis;
	int analogVal_light;//����
	int analogVal;//���
	int tmp, status;
	extern volatile int globalCounter;
	//int fd;
	int acclX, acclY, acclZ;
	int gyroX, gyroY, gyroZ;
	double acclX_scaled, acclY_scaled, acclZ_scaled;
	double gyroX_scaled, gyroY_scaled, gyroZ_scaled;
	double x, y;
	int tmp_encoder = 0;
	if(wiringPiSetup() == -1){
		printf("setup wiringPi failed !");
		return 1;
	}
	encoder_init();
	if(wiringPiISR(SWPin, INT_EDGE_FALLING, &btnISR) < 0){
		fprintf(stderr, "Unable to init ISR\n",strerror(errno));	
		return 1;
	}
	init();
	mpu_init();
	ultraInit();
	buzzerInit();
	digitalWrite(BuzzerPin, HIGH);
	pcf8591Setup(PCF, 0x48);
	pinMode(DOpin, INPUT);
	ledInit();
	status = 0;
	clear();
	write(0, 0, "Not raining!");
	write(0, 1, "distance:0");
	while(1)
	{
		
		/*ultrasonic + buzzer���������*/
		dis = disMeasure();
		printf("Distance:%0.2f cm\n\n",dis);
		buzzer(dis);
		/*photoresistor*/
		analogVal_light = analogRead(PCF + 0);//����ģת�����ж����������ֵ
		if(analogVal_light >= 180)ledColorSet(0xff);
		else ledColorSet(0x00);
		printf("Light: %d\n", analogVal_light);
		/*mpu������*/
		acclX = read_word_2c(0x3B);
		acclY = read_word_2c(0x3D);
		acclZ = read_word_2c(0x3F);
		acclX_scaled = acclX / 16384.0;
		acclY_scaled = acclY / 16384.0;
		acclZ_scaled = acclZ / 16384.0;
		x = get_x_rotation(acclX_scaled, acclY_scaled, acclZ_scaled);
		y = get_y_rotation(acclX_scaled, acclY_scaled, acclZ_scaled);
		mpu_buzzer(x, y);
		/*rotary_encoder��ת������*/
		rotaryDeal();
		if (tmp_encoder != globalCounter)/*��ת������ת��Ȧ��*/{
			display_distance(distance, str, globalCounter);
			tmp_encoder = globalCounter;
		}
		/*raining detector*/
		analogVal = analogRead(PCF + 1);
		if(analogVal<200)
		{
			tmp=0;
		}
		else
		{
			tmp=1;
		}
		printf("Rain:%d\n", analogVal);
		
			Print(tmp);
			status = tmp;
	
	}
	return 0;
	}
