#ifndef PHOTORESISTOR_H
#define PHOTORESISTOR_H
#include <stdio.h>
#include <wiringPi.h>
#include <pcf8591.h>
#include <softPwm.h>
#include <math.h>
#endif 

#define uchar unsigned char
void ledInit(void);
void ledColorSet(uchar r_val);
#define		PCF     120
#define		DOpin	0
#define LedPinRed    26
