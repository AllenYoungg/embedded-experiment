#ifndef ROTARY_ENCODER_H
#define ROTARY_ENCODER_H
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <wiringPi.h>
void btnISR(void);
void rotaryDeal(void);
void encoder_init(void);
#endif
#define  RoAPin    22
#define  RoBPin    3
#define  SWPin     21
