#include "mpu.h"
int fd_mpu;

int read_word_2c(int addr)
{
  int val;
  val = wiringPiI2CReadReg8(fd_mpu, addr);
  val = val << 8;
  val += wiringPiI2CReadReg8(fd_mpu, addr+1);
  if (val >= 0x8000)
    val = -(65536 - val);

  return val;
}

double dist(double a, double b)
{
  return sqrt((a*a) + (b*b));
}

double get_y_rotation(double x, double y, double z)
{
  double radians;
  radians = atan2(x, dist(y, z));
  return -(radians * (180.0 / M_PI));
}

double get_x_rotation(double x, double y, double z)
{
  double radians;
  radians = atan2(y, dist(x, z));
  return (radians * (180.0 / M_PI));
}

void mpu_buzzer(double x, double y)
{
  if(x>=45 || x<= -45 || y>=45 || y<=-45)
    {
      digitalWrite(BuzzerPin, LOW);
			delay(150);
			digitalWrite(BuzzerPin, HIGH);
			delay(150);
      }
  }
  
void mpu_init(void)
{
  fd_mpu = wiringPiI2CSetup (0x68);
	wiringPiI2CWriteReg8 (fd_mpu,0x6B,0x00);//disable sleep mode 
  }

