#ifndef ULTRASONIC_H
#define ULTRASONIC_H
#include <wiringPi.h>
#include <stdio.h>
#include <sys/time.h>
void ultraInit(void);
void buzzerInit(void);
float disMeasure(void);
void buzzer(float dis);
#endif

#define Trig    27
#define Echo    24
#define BuzzerPin      23
